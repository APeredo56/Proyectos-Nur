import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Pregunta1 {

    public List<Integer> resolver(InputStream in) {
        List<Integer> salidas = new ArrayList<>();

        //Completar código

        //si se desea imprimir una linea, hacer uso del método out
        //por ejemplo, si deseo imprimir el valor -1, realizar lo siguiente:
        //out(salidas, -1);

        return salidas;
    }

    public void out(List<Integer> salida, int valor){
        salida.add(valor);
        System.out.println(valor);
    }

    public static void main(String[] args) {
        Pregunta1 pregunta1 = new Pregunta1();
        pregunta1.resolver(System.in);
    }

}
