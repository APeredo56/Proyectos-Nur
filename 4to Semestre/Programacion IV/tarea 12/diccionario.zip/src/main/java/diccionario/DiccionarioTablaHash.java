package diccionario;

import java.util.ArrayList;
import java.util.List;

public class DiccionarioTablaHash<K, V> extends Diccionario<K, V> {

    private DiccionarioSecuencia<K,V>[] elementos;
    private float factorCarga;
    private int limiteElementos;

    public DiccionarioTablaHash(Comparador<K> comparador) {
        super(comparador);
        init();
    }

    public DiccionarioTablaHash() {
        super();
        init();
    }

    @Override
    public void insertar(K key, V value) {
        int indice = getIndice(key);
        if(elementos[indice] == null){
            elementos[indice] = new DiccionarioSecuencia<>(comparador);
        }
        elementos[indice].insertar(key, value);
        cantidadElementos++;
        if(cantidadElementos > limiteElementos){
            //rehash();
        }
    }

    private int getIndice(K key) {
        return getIndice(key, elementos.length);
    }

    private int getIndice(K key, int n) {

        return (this.comparador.getHashCode(key) & 0x7FFFFFFF ) % n;
    }

    @Override
    public V obtener(K key) {
        return null;
    }

    @Override
    public V eliminar(K key) {
        return null;
    }

    @Override
    public boolean contieneLlave(K key) {
        return false;
    }

    @Override
    public List<K> getLlaves() {
        List<K> llaves = new ArrayList<>();
        for (DiccionarioSecuencia<K, V> diccionarioSecuencia : elementos) {
            if(diccionarioSecuencia != null){
                llaves.addAll(diccionarioSecuencia.getLlaves());
            }
        }

        return llaves;
    }

    @Override
    public List<V> getValores() {
        List<V> valores = new ArrayList<>();
        for (DiccionarioSecuencia<K, V> diccionarioSecuencia : elementos) {
            if(diccionarioSecuencia != null){
                valores.addAll(diccionarioSecuencia.getValores());
            }
        }

        return valores;
    }

    private void init(){
        elementos = new DiccionarioSecuencia[11];
        factorCarga = 0.75f;
        limiteElementos = (int) (elementos.length * factorCarga);
    }



}
