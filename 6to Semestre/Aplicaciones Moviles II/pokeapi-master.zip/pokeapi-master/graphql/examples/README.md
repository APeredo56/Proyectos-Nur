# GraphQL examples

You can use all the `.gql` examples in our console at https://beta.pokeapi.co/graphql/console/.

Inside the folders you find GraphQL queries implemented in different languages, frameworks and libraries.
